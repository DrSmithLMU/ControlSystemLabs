function F = animate_Starship(t,u,d,alpha,alpha_d,alpha_offset,num_frames,fig,image_)

% t: time vector
% u: normalized control input vector (extra columns are P, D, I components)
% d: disturbance vector
% alpha: angle of attack vector
% alpha_d: desired angle of attack vector
% alpha_offset: angle of zero angle of attack (i.e., velcoity direction)
% num_frames: number of frames for movie
% fig: figure number to use
% image_: data for creating the image of the Starship

figure(fig)
F(num_frames) = struct('cdata',[],'colormap',[]);

t_even = interp1([1 num_frames],t([1 end]),1:num_frames);
alpha_even = interp1(t,alpha_offset+alpha,t_even);
alpha_d_even = interp1(t,alpha_offset+alpha_d,t_even);
u_even = interp1(t,u,t_even);
d_even = interp1(t,d,t_even);

if size(u_even,1)>size(u_even,2)
    u_even = u_even';
end
if size(d_even,1)>size(d_even,2)
    d_even = d_even';
end

% rectify components of u(t)
if size(u_even,1) > 1
    u_even(2:end,:) = u_even(2:end,:) .* (max(-1,min(1,sum(u_even(2:end))))/(sum(u_even(2:end))+1e-10));
end

u_colors = get(gca,'colororder');
legend_entries = {'u(t)','u_P(t)','u_D(t)','u_F_F(t)','d(t)'};

R = @(th_) [cos(th_) sin(th_);-sin(th_) cos(th_)];

% plasma = 0.85 * R(-alpha_offset) * [-1.4 cos(pi*(1.05:.025:1.95)) 1.4;2 .2+.9*sin(pi*(1.05:.025:1.95)) 2];
plasma = 0.85 * R(-alpha_offset) * [-1.4 cos(pi*(1.075:.025:1.925)) 1.4;2 .3+sin(pi*(1.075:.025:1.925)) 2];

for fr = 1:num_frames
    clf
    set(gcf,'Visible','on')
    hold on
    axis('equal')
    axis([-1 1 -1 1])
    set(gca,'Color','none')
    set(gca,'Visible','off')

%     plot(sin(alpha_offset)*[0 -1], -cos(alpha_offset)*[0 -1],'Color',[200 178 237]/255,'LineWidth',20)
    plot(plasma(1,:),plasma(2,:),'Color',[255 240 255]/255,'LineWidth',16)
    plot(plasma(1,:),plasma(2,:),'Color',[200 178 237]/255,'LineWidth',8)

    plot(sin(alpha_d_even(fr))*[-1 1], -cos(alpha_d_even(fr))*[-1 1],'k','LineWidth',6)
    plot(.995*sin(alpha_d_even(fr))*[-1 1], -.995*cos(alpha_d_even(fr))*[-1 1],'g','LineWidth',4)
    
    d_angle_total = -pi/6 * d_even(1,fr);
    plot( .85*sin(alpha_even(fr)+(0:d_angle_total/8:d_angle_total)), ...
         -.85*cos(alpha_even(fr)+(0:d_angle_total/8:d_angle_total)), ...
          'Color',u_colors(5,:),'LineWidth',30);
    
    u_angle_total = -pi/6 * u_even(1,fr);
    plot( .85*sin(pi+alpha_even(fr)+(0:u_angle_total/8:u_angle_total)), ...
         -.85*cos(pi+alpha_even(fr)+(0:u_angle_total/8:u_angle_total)), ...
          'Color',u_colors(1,:),'LineWidth',30);
                
    u_angle = -pi/2 * sign(u_even(:,fr)).*sqrt(abs(u_even(:,fr)));
    for n = size(u,2):-1:2
        plot( (1-.05*n)*sin(pi+alpha_even(fr)+(0:u_angle(n)/8:u_angle(n))), ...
             -(1-.05*n)*cos(pi+alpha_even(fr)+(0:u_angle(n)/8:u_angle(n))), ...
              'Color',u_colors(n,:),'LineWidth',0.5+15*abs(u_angle(n)) );
    end
    
    plot(.985*sin(alpha_even(fr))*[-1 1], -.985*cos(alpha_even(fr))*[-1 1],'k','LineWidth',2)

    BFS_black = 1.5*image_.black*R(alpha_even(fr));
    BFS_white = 1.5*image_.white*R(alpha_even(fr));
    
    patch(BFS_white(:,1),BFS_white(:,2),'w')
    patch(BFS_black(:,1),BFS_black(:,2),'k')
    
    text(-.9,-.9,['t = ' num2str(t_even(fr),'%1.1f') ' s'])
    for n = 1:size(u,2)
        text(.9,-.5-.1*n,legend_entries{n},'Color',u_colors(n,:))
    end
    text(.9,-.5-.1*5,legend_entries{5},'Color',u_colors(5,:))

    F(fr) = getframe;
end
end